import discord
from discord.ext import commands 

PREFIX = ""
TOKEN = " "

bot = commands.Bot(command_prefix=PREFIX, self_bot=True)

@bot.event
async def on_ready():
    print(f"{bot.user.name}")

@bot.command()
async def ping(ctx):
    await ctx.send("pong")


bot.run(TOKEN)
